from decimal import Decimal

from .models import City
from .cart123 import Cart  # فرض می‌کنم سبد خریدت این‌جوریه


def calculate_shipping_cost(cart, city: City | None) -> Decimal:
    """
    بر اساس شهر و مجموع سبد خرید، هزینه ارسال را محاسبه می‌کند.
    """
    if not city or not city.delivery_available:
        return Decimal("0")

    cart_total = Decimal(cart.get_total_price())  # یا هر متدی داری

    # اگر آستانه ارسال رایگان تعریف شده و سبد از آن بیشتر بود → ۰
    if city.free_shipping_threshold and cart_total >= city.free_shipping_threshold:
        return Decimal("0")

    return Decimal(city.shipping_base_fee or 0)
