# iranmarket/settings_dev.py
from .settings_base import *

# تنظیمات مخصوص توسعه (لوکال)
DEBUG = True

ALLOWED_HOSTS = []

# اگر خواستی چیزی فقط برای dev override کنی، این‌جا بنویس
